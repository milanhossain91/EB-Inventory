<?php

namespace EB\Inventory;

/**
 * The admin class
 */
class Admin {

    /**
     * Initialize the class
     */

    function __construct() {

    	 $productcategory = new Admin\Productcategory();

    	 $this->dispatch_actions( $productcategory );

    	 new Admin\Menu( $productcategory );

    	 //product stock//

    	 $productstock = new Admin\Productstock();

    	 $this->stock_dispatch_actions( $productstock );

    	 //new Admin\Menu( $productstock );
    }

    /**
     * Dispatch and bind actions
     *
     * @return void
     */
    public function dispatch_actions( $productcategory ) {

        add_action( 'admin_init', [ $productcategory, 'form_handler' ] );
        add_action( 'admin_post_eb_inventory_delete_category', [ $productcategory, 'delete_address' ] );

    }


   /**
     * Dispatch stock and bind actions
     *
     * @return void
     */
    public function stock_dispatch_actions( $productcategory ) {

        add_action( 'admin_init', [ $productcategory, 'form_handler' ] );
        add_action( 'admin_post_eb_inventory_delete_category', [ $productcategory, 'delete_address' ] );

    }
}