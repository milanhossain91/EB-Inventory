<?php

namespace EB\Inventory\Admin;

/**
 * Productcategory Handler class
 */
class Productstock {

    public $errors = [];

    /**
     * Plugin page handler
     *
     * @return void
     */
    public function plugin_page() {
        $action = isset( $_GET['action'] ) ? $_GET['action'] : 'list';

        switch ( $action ) {
            case 'new':
                $template = __DIR__ . '/views/stock/stock-new.php';
                break;

            case 'edit':
                $template = __DIR__ . '/views/stock/stock-edit.php';
                break;

            case 'view':
                $template = __DIR__ . '/views/stock/stock-view.php';
                break;

            default:
                $template = __DIR__ . '/views/stock/stock-list.php';
                break;
        }

        if ( file_exists( $template ) ) {
            include $template;
        }
    }

    /**
     * Handle the form
     *
     * @return void
     */

    public function form_handler() {

        if ( ! isset( $_POST['submit_cat_name'] ) ) {
            return;
        }

        if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'new-category' ) ) {
            wp_die( 'Are you cheating?' );
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Are you cheating?' );
        }

        $name    = isset( $_POST['name'] ) ? sanitize_text_field( $_POST['name'] ) : '';

        if ( ! empty( $this->errors ) ) {
            return;
        }

        $insert_id = eb_inventory_insert_category( [
            'name'    => $name
        ] );

        if ( is_wp_error( $insert_id ) ) {
            wp_die( $insert_id->get_error_message() );
        }

        $redirected_to = admin_url( 'admin.php?page=eb-inventory&inserted=true' );
        wp_redirect( $redirected_to );
        exit;
    }


    public function delete_address() {
        if ( ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'eb_inventory_delete_category' ) ) {
            wp_die( 'Are you cheating?' );
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Are you cheating?' );
        }

        $id = isset( $_REQUEST['id'] ) ? intval( $_REQUEST['id'] ) : 0;

        if ( eb_inventory_delete_category( $id ) ) {
            $redirected_to = admin_url( 'admin.php?page=eb-inventory&address-deleted=true' );
        } else {
            $redirected_to = admin_url( 'admin.php?page=eb-inventory&address-deleted=false' );
        }

        wp_redirect( $redirected_to );
        exit;
    }
}