<?php

namespace EB\Inventory\Admin;

/**
 * The Menu handler class
 */
class Menu {

    /**
     * Initialize the class
     */
    function __construct() {
        add_action( 'admin_menu', [ $this, 'admin_menu' ] );
    }

    /**
     * Register admin menu
     *
     * @return void
     */
    public function admin_menu() {

        $parent_slug = 'eb-inventory';
        $capability = 'manage_options';

        
        add_menu_page( __( 'EB Inventory', 'eb-inventory' ), __( 'Inventory', 'eb-inventory' ), $capability, $parent_slug, [ $this, 'product_category' ], 'dashicons-screenoptions' );

        add_submenu_page( $parent_slug, __( 'Product Category', 'eb-inventory' ), __( 'Product Category', 'eb-inventory' ), $capability, $parent_slug, [ $this, 'product_category' ], 'dashicons-screenoptions' );

        add_submenu_page( $parent_slug, __( 'Product Stock', 'eb-inventory' ), __( 'Product Stock', 'eb-inventory' ), $capability, 'eb-inventory-stock', [ $this, 'product_stock' ] );

        add_submenu_page( $parent_slug, __( 'Income', 'eb-inventory' ), __( 'Income', 'eb-inventory' ), $capability, 'eb-inventory-income', [ $this, 'settings_income' ] );

        add_submenu_page( $parent_slug, __( 'Expenses', 'eb-inventory' ), __( 'Expenses', 'eb-inventory' ), $capability, 'eb-inventory-expenses', [ $this, 'settings_expenses' ] );

        add_submenu_page( $parent_slug, __( 'Report', 'eb-inventory' ), __( 'Report', 'eb-inventory' ), $capability, 'eb-inventory-report', [ $this, 'settings_report' ] );
    }

    /**
     * Render the plugin page
     *
     * @return void
     */
    public function product_category() {
        $productcategory = new Productcategory();
        $productcategory->plugin_page();
    }

    /**
     * Render the plugin page
     *
     * @return void
     */
    public function product_stock() {
        
        $productstock = new Productstock();
        $productstock->plugin_page();

    }

    /**
     * Render the plugin page
     *
     * @return void
     */
    public function settings_income() {
        echo 'Hello Income';
    }

    /**
     * Render the plugin page
     *
     * @return void
     */
    public function settings_expenses() {
        echo 'Hello Expenses';
    }

    /**
     * Render the plugin page
     *
     * @return void
     */
    public function settings_report() {
        echo 'Hello Report';
    }
}