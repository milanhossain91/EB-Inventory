<?php

namespace EB\Inventory;

/**
 * Installer class
 */
class Installer {

    /**
     * Run the installer
     *
     * @return void
     */
    public function run() {
        $this->add_version();
        $this->create_tables();
        $this->product_stock_create_tables();
        $this->income_create_tables();
        $this->expenses_create_tables();
        $this->sales_create_tables();
        $this->vendors_create_tables();
    }

    /**
     * Add time and version on DB
     */
    public function add_version() {
        $installed = get_option( 'eb_inventory_installed' );

        if ( ! $installed ) {
            update_option( 'eb_inventory_installed', time() );
        }

        update_option( 'eb_inventory_version', EB_INVENTORY_VERSION );
    }

    /**
     * Create product category necessary database tables
     *
     * @return void
     */
    public function create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $schema = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ebi_categorys` (
          `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
          `name` varchar(100) NOT NULL DEFAULT '',
          `created_by` bigint(20) unsigned NOT NULL,
          `created_at` datetime NOT NULL,
          PRIMARY KEY (`id`)
        ) $charset_collate";

        if ( ! function_exists( 'dbDelta' ) ) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }

        dbDelta( $schema );
    }

    /**
     * Create product stock necessary database tables
     *
     * @return void
     */
    public function product_stock_create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $schema = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ebi_stocks` (
          `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
          `p_name` varchar(100) NOT NULL DEFAULT '',
          `p_category` int(11) NOT NULL DEFAULT '0',
          `p_qty` int(11) NOT NULL DEFAULT '0',
          `p_price` int(11) NOT NULL DEFAULT '0',
          `p_vendor` int(11) NOT NULL DEFAULT '0',
          `p_date_stock` datetime NOT NULL,
          `created_by` bigint(20) unsigned NOT NULL,
          `created_at` datetime NOT NULL,
          PRIMARY KEY (`id`)
        ) $charset_collate";

        if ( ! function_exists( 'dbDelta' ) ) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }

        dbDelta( $schema );
    }

    /**
     * Create product income necessary database tables
     *
     * @return void
     */
    public function income_create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $schema = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ebi_incomes` (
          `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
          `transaction` varchar(255) NOT NULL,
          `credit` int(11) NOT NULL DEFAULT '0',
          `t_date` datetime NOT NULL,
          `created_by` bigint(20) unsigned NOT NULL,
          `created_at` datetime NOT NULL,
          PRIMARY KEY (`id`)
        ) $charset_collate";

        if ( ! function_exists( 'dbDelta' ) ) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }

        dbDelta( $schema );
    }

    /**
     * Create product expenses necessary database tables
     *
     * @return void
     */
    public function expenses_create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $schema = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ebi_expenses` (
          `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
          `transaction` varchar(255) NOT NULL,
          `debit` int(11) NOT NULL DEFAULT '0',
          `t_date` datetime NOT NULL,
          `created_by` bigint(20) unsigned NOT NULL,
          `created_at` datetime NOT NULL,
          PRIMARY KEY (`id`)
        ) $charset_collate";

        if ( ! function_exists( 'dbDelta' ) ) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }

        dbDelta( $schema );
    }


    /**
     * Create product Sales necessary database tables
     *
     * @return void
     */
    public function sales_create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $schema = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ebi_sales` (
          `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
          `cat_id` int(11) NOT NULL DEFAULT '0',
          `p_id` int(11) NOT NULL DEFAULT '0',
          `transaction` varchar(255) NOT NULL,
          `p_price` int(11) NOT NULL,
          `s_date` datetime NOT NULL,
          `created_by` bigint(20) unsigned NOT NULL,
          `created_at` datetime NOT NULL,
          PRIMARY KEY (`id`)
        ) $charset_collate";

        if ( ! function_exists( 'dbDelta' ) ) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }

        dbDelta( $schema );
    }

    /**
     * Create product vendor necessary database tables
     *
     * @return void
     */
    public function vendors_create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $schema = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ebi_vendors` (
          `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
          `name` varchar(255) NOT NULL,
          `email` varchar(255) NOT NULL,
          `phone` int(11) NOT NULL,
          `created_by` bigint(20) unsigned NOT NULL,
          `created_at` datetime NOT NULL,
          PRIMARY KEY (`id`)
        ) $charset_collate";

        if ( ! function_exists( 'dbDelta' ) ) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }

        dbDelta( $schema );
    }
}